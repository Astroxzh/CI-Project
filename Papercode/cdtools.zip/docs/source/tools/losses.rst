Losses
======

.. automodule:: cdtools.tools.losses
   :members:
