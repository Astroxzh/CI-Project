Initializers
============

.. automodule:: cdtools.tools.initializers
   :members:
