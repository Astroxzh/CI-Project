Data
====

.. automodule:: cdtools.tools.data
   :members:
