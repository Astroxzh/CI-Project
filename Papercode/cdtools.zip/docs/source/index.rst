.. toctree::
   :hidden:
   :maxdepth: 1

   self
   installation
   examples
   tutorial
   general
   datasets
   models
   tools/index
   indices_tables
   

.. include:: intro.rst

